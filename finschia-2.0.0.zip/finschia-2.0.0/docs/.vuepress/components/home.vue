<template>
  <div></div>
</template>

<script>
export default {
  mounted() {
    window.location.assign(`${this.$site.base}hub-overview/overview.html`)
  }
}
</script>