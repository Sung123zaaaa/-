<!--
order: 3
-->

# Delegator Security

<--
It is necessary to write when a public blockchain is released.
-->
TBD
