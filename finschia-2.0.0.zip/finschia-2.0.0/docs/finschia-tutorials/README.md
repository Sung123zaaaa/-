<!--
order: false
parent:
  order: 3
-->

# Finschia Tutorials

This folder contains tutorials related to the `Finschia` application.

- [Introduction to the `Finschia` application](./what-is-finschia.md)
- [Installing `Finschia`](./installation.md)
- [Deploying a `Finschia` testnet](./deploy-testnet.md)