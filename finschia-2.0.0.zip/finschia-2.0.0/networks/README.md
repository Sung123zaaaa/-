# Networks

Here contains the files required for automated deployment of either local or remote testnets.

Doing so is best accomplished using the `make` targets. For more information, see the
[networks documentation](../docs/finschia-tutorials/deploy-testnet.md)
